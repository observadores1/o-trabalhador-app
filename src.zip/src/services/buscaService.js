// src/services/buscaService.js - VERSÃO FINAL SEM RPC (À PROVA DE CACHE)

import { supabase } from './supabaseClient';

/**
 * Busca perfis de trabalhadores usando o construtor de queries, sem RPC.
 * @param {object} filtros - Objeto com os filtros de busca.
 */
export const buscarPerfis = async (filtros) => {
  if (!filtros.habilidade) {
    return { data: [], error: { message: "A habilidade é um filtro obrigatório." } };
  }

  // Começa a query a partir da VIEW 'perfis_completos'.
  // Esta view já une as tabelas 'perfis' e 'perfis_profissionais'.
  let query = supabase
    .from('perfis_completos')
    .select(`
      id, apelido, titulo_profissional, foto_perfil_url,
      avaliacao_media, bairro, cidade, estado, habilidades
    `);

  // 1. Filtro OBRIGATÓRIO por HABILIDADE
  // Converte o array de habilidades para texto e usa 'ilike' (case-insensitive).
  query = query.ilike('habilidades::text', `%${filtros.habilidade}%`);

  // 2. Filtros OPCIONAIS de Localização (usando 'ilike')
  if (filtros.estado) {
    query = query.ilike('estado', `%${filtros.estado}%`);
  }
  if (filtros.cidade) {
    query = query.ilike('cidade', `%${filtros.cidade}%`);
  }
  if (filtros.bairro) {
    query = query.ilike('bairro', `%${filtros.bairro}%`);
  }

  // 3. Garante que o resultado contenha apenas trabalhadores disponíveis.
  query = query.eq('disponivel_para_servicos', true);
  query = query.eq('tipo_usuario', 'trabalhador');

  // Executa a query final.
  const { data, error } = await query;

  if (error) {
    console.error('Erro na busca com construtor de query:', error);
    return { data: null, error };
  }

  return { data, error: null };
};
