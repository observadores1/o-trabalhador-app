// src/PaginaNovaOS.js - Criado por Jeferson Gnoatto
// TAREFA 3.3: VERSÃO COM AVISOS CORRIGIDOS

import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
// A importação de 'useAuth' foi removida, pois 'user' não é mais necessário aqui
import { supabase } from './services/supabaseClient';
// A importação de 'FormularioOrdemServico' foi removida
import HeaderEstiloTop from './components/HeaderEstiloTop';
import './PaginaNovaOS.css';
import './components/MeusTrabalhos.css';

const PaginaNovaOS = () => {
  const { osId } = useParams();
  const navigate = useNavigate();
  // A variável 'user' foi removida
  const [os, setOs] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const carregarDetalhesOS = async () => {
      if (!osId) {
        setIsLoading(false);
        return;
      }
      setIsLoading(true);
      const { data, error } = await supabase
        .from('ordens_de_servico')
        .select('*')
        .eq('id', osId)
        .single();
      
      if (error) {
        console.error("Erro ao carregar detalhes da OS:", error);
        alert("Não foi possível carregar os detalhes do serviço.");
        navigate('/meus-trabalhos');
      } else {
        setOs(data);
      }
      setIsLoading(false);
    };
    carregarDetalhesOS();
  }, [osId, navigate]);
  
  if (isLoading) {
    return (
      <div className="page-container">
        <HeaderEstiloTop showUserActions={false} />
        <main className="main-content"><p>Carregando detalhes do serviço...</p></main>
      </div>
    );
  }

  if (!os) {
    return (
        <div className="page-container">
            <HeaderEstiloTop showUserActions={false} />
            <main className="main-content"><p>ID de serviço inválido.</p></main>
        </div>
    );
  }

  return (
    <div className="page-container">
      <HeaderEstiloTop showUserActions={false} />
      <main className="main-content">
        <div className="profile-section">
            <div className="pagina-os-header">
                <div className="header-com-status">
                    <h1>{os.titulo_servico}</h1>
                    <span className={`os-status-badge status-${os.status}`}>
                        {os.status.replace(/_/g, ' ')}
                    </span>
                </div>
                <p>Detalhes do serviço solicitado.</p>
            </div>
            <div className="pagina-os-main">
                <div className="detalhes-os-container">
                    <p><strong>Descrição:</strong> {os.descricao_servico}</p>
                    <p><strong>Habilidade Requerida:</strong> {os.habilidade}</p>
                    <p><strong>Endereço:</strong> {`${os.endereco.rua}, ${os.endereco.numero}, ${os.endereco.bairro}, ${os.endereco.cidade} - ${os.endereco.estado}`}</p>
                    <p><strong>Valor Proposto:</strong> {os.valor_acordado ? `R$ ${os.valor_acordado}` : 'A combinar'}</p>
                </div>
            </div>
        </div>
      </main>
    </div>
  );
};

export default PaginaNovaOS;
