import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseCliente.js'; // <-- CORREÇÃO FINAL E DEFINITIVA
import { Link } from 'react-router-dom';
import './MeusTrabalhos.css';

const MeusTrabalhos = () => {
    const [trabalhos, setTrabalhos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [userId, setUserId] = useState(null);

    useEffect(() => {
        const fetchSession = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            if (session) {
                setUserId(session.user.id);
            } else {
                console.log("Nenhuma sessão encontrada.");
                setLoading(false);
            }
        };

        fetchSession();
    }, []);

    useEffect(() => {
        if (userId) {
            const fetchTrabalhos = async () => {
                setLoading(true);
                const { data, error } = await supabase
                    .from('ordens_de_servico')
                    .select(`
                        *,
                        profiles:trabalhador_id (
                            full_name,
                            avatar_url
                        )
                    `)
                    .eq('professional_id', userId);

                if (error) {
                    console.error('Erro ao buscar trabalhos:', error);
                } else {
                    setTrabalhos(data);
                }
                setLoading(false);
            };

            fetchTrabalhos();
        }
    }, [userId]);

    const getStatusClass = (status) => {
        switch (status) {
            case 'Aprovado':
                return 'status-aprovado';
            case 'Pendente':
                return 'status-pendente';
            case 'Recusado':
                return 'status-recusado';
            default:
                return '';
        }
    };

    if (loading) {
        return <div>Carregando trabalhos...</div>;
    }

    return (
        <div className="meus-trabalhos-container">
            <h2>Meus Trabalhos</h2>
            {trabalhos.length > 0 ? (
                <ul className="trabalhos-list">
                    {trabalhos.map((trabalho) => (
                        <li key={trabalho.id} className="trabalho-item">
                            <Link to={`/ordem-servico/${trabalho.id}`} className="trabalho-link">
                                <div className="trabalho-info">
                                    <p className="trabalho-title"><strong>{trabalho.title}</strong></p>
                                    <p className="trabalho-description">{trabalho.description}</p>
                                </div>
                                <div className="trabalho-status-container">
                                    <span className={`trabalho-status ${getStatusClass(trabalho.status)}`}>
                                        {trabalho.status}
                                    </span>
                                </div>
                            </Link>
                        </li>
                    ))}
                </ul>
            ) : (
                <p>Nenhum trabalho encontrado.</p>
            )}
        </div>
    );
};

export default MeusTrabalhos;
