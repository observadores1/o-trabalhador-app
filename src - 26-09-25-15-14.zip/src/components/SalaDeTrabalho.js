/**
 * @file SalaDeTrabalho.js
 * @description Componente que representa a sala de negociação e acompanhamento de uma OS. (Versão de Reparação Final - Limpa)
 * @author Jeferson Gnoatto & Manus AI
 * @date 2025-09-26
 * Louvado seja Cristo, Louvado seja Deus
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../services/supabaseClient';
import HeaderEstiloTop from './HeaderEstiloTop';
import FormularioAvaliacao from './FormularioAvaliacao';
import './SalaDeTrabalho.css';

// Componente de visualização de avaliação (reutilizado de DetalhesOS)
const EstrelasDisplay = ({ nota }) => {
  if (!nota || nota === 0) return null;
  return (
    <div className="estrelas-display">
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < nota ? 'preenchida' : ''}>★</span>
      ))}
    </div>
  );
};

const SalaDeTrabalho = () => {
    const { osId } = useParams();
    const { user } = useAuth();
    const [os, setOs] = useState(null);
    const [contratante, setContratante] = useState(null);
    const [trabalhador, setTrabalhador] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [mensagens, setMensagens] = useState([]);
    const [novaMensagem, setNovaMensagem] = useState('');
    const chatBoxRef = useRef(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showConcludeForm, setShowConcludeForm] = useState(false);
    const [comentarioConclusao, setComentarioConclusao] = useState('');
    const [avaliacaoFinal, setAvaliacaoFinal] = useState(null);

    const carregarDadosTrabalho = useCallback(async (showLoading = true) => {
        if (!osId || !user) return;
        if (showLoading) setIsLoading(true);
        try {
            const { data: osData, error: osError } = await supabase.from('ordens_de_servico').select('*').eq('id', osId).single();
            if (osError) throw osError;
            if (user.id !== osData.contratante_id && user.id !== osData.trabalhador_id) {
                throw new Error("Você não tem permissão para acessar esta sala de trabalho.");
            }
            setOs(osData);

            if (osData.avaliado_pelo_contratante) {
                const { data: avaliacaoData, error: avaliacaoError } = await supabase.from('avaliacoes_quesitos').select('quesito, nota').eq('ordem_de_servico_id', osId);
                if (avaliacaoError) throw avaliacaoError;
                const avaliacaoObj = avaliacaoData.reduce((acc, item) => ({ ...acc, [item.quesito]: item.nota }), {});
                setAvaliacaoFinal(avaliacaoObj);
            }

            if (!contratante || !trabalhador) {
                const idsParaBuscar = [osData.contratante_id, osData.trabalhador_id];
                const { data: perfisData, error: perfisError } = await supabase.from('perfis_completos').select('*').in('id', idsParaBuscar);
                if (perfisError) throw perfisError;
                setContratante(perfisData.find(p => p.id === osData.contratante_id));
                setTrabalhador(perfisData.find(p => p.id === osData.trabalhador_id));
            }
            const { data: mensagensData, error: mensagensError } = await supabase.from('mensagens').select('*').eq('ordem_de_servico_id', osId).order('created_at', { ascending: true });
            if (mensagensError) throw mensagensError;
            setMensagens(mensagensData);
        } catch (err) {
            console.error("Erro ao carregar dados da sala de trabalho:", err);
            setError(err.message);
        } finally {
            if (showLoading) setIsLoading(false);
        }
    }, [osId, user, contratante, trabalhador]);

    useEffect(() => { carregarDadosTrabalho(); }, [carregarDadosTrabalho]);

    useEffect(() => {
        if (!osId || os?.status === 'concluida' || os?.status === 'cancelada') return;
        const channel = supabase.channel(`sala_trabalho_${osId}`)
            .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'mensagens', filter: `ordem_de_servico_id=eq.${osId}` },
                (payload) => { setMensagens((prevMensagens) => [...prevMensagens, payload.new]); })
            .subscribe();
        return () => { supabase.removeChannel(channel); };
    }, [osId, os?.status]);

    useEffect(() => {
        if (chatBoxRef.current) {
            chatBoxRef.current.scrollTop = chatBoxRef.current.scrollHeight;
        }
    }, [mensagens]);

    const handleEnviarMensagem = async (e) => {
        e.preventDefault();
        if (novaMensagem.trim() === '' || !user || !osId) return;
        const { error } = await supabase.from('mensagens').insert({ ordem_de_servico_id: osId, remetente_id: user.id, conteudo: novaMensagem.trim() });
        if (error) {
            console.error('Erro ao enviar mensagem:', error);
            alert('Não foi possível enviar a mensagem.');
        } else {
            setNovaMensagem('');
        }
    };

    const handleConcluirServico = async (dadosAvaliacao = null) => {
        setIsSubmitting(true);
        try {
            if (user.id === contratante.id) {
                if (!dadosAvaliacao) throw new Error("Dados da avaliação são obrigatórios.");
                
                const { error: rpcError } = await supabase.rpc('concluir_e_avaliar_servico_pelo_contratante', {
                    os_id_param: osId,
                    comentario_param: comentarioConclusao,
                    avaliacoes: dadosAvaliacao 
                });
                if (rpcError) throw rpcError;

            } else {
                if (!comentarioConclusao.trim()) {
                    alert("O relatório de conclusão é obrigatório.");
                    setIsSubmitting(false);
                    return;
                }
                const { error: rpcError } = await supabase.rpc('concluir_servico_pelo_trabalhador', {
                    os_id_param: osId,
                    comentario_param: comentarioConclusao
                });
                if (rpcError) throw rpcError;
            }
            alert("Operação realizada com sucesso!");
            setShowConcludeForm(false);
            await carregarDadosTrabalho(false);
        } catch (err) {
            console.error("Erro detalhado ao concluir o serviço:", err);
            alert(`Ocorreu um erro: ${err.message}\n\nPor favor, tente novamente.`);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleAvaliarServicoConcluido = async (dadosAvaliacao) => {
        setIsSubmitting(true);
        try {
            if (!dadosAvaliacao) throw new Error("Dados da avaliação não foram encontrados.");
            
            const { error } = await supabase.rpc('avaliar_servico_concluido', {
                os_id_param: osId,
                avaliacoes: dadosAvaliacao
            });
            if (error) throw error;
            alert("Avaliação enviada com sucesso!");
            await carregarDadosTrabalho(false);
        } catch (err) {
            console.error("Erro detalhado ao enviar avaliação:", err);
            alert(`Ocorreu um erro: ${err.message}\n\nPor favor, tente novamente.`);
        } finally {
            setIsSubmitting(false);
        }
    };

    const renderAcoesFinais = () => {
        const isContratante = user.id === contratante?.id;
        const isFinalizado = os?.status === 'concluida' || os?.status === 'cancelada';

        if (os?.status === 'concluida' && os.avaliado_pelo_contratante) {
            return (
                <div className="extrato-final">
                    <h4>Resumo da Conclusão</h4>
                    {os.comentario_encerramento_contratante && <p><strong>Comentário do Contratante:</strong> {os.comentario_encerramento_contratante}</p>}
                    {os.comentario_encerramento_trabalhador && <p><strong>Relatório do Trabalhador:</strong> {os.comentario_encerramento_trabalhador}</p>}
                    <h4>Avaliação Realizada</h4>
                    {avaliacaoFinal ? (
                        <div className="avaliacao-grid">
                            {Object.entries(avaliacaoFinal).map(([quesito, nota]) => (
                                <div className="quesito-display" key={quesito}><span>{quesito.replace(/_/g, ' ')}:</span> <EstrelasDisplay nota={nota} /></div>
                            ))}
                        </div>
                    ) : <p>Carregando avaliação...</p>}
                </div>
            );
        }

        const avaliacaoPendente = os?.status === 'concluida' && isContratante && !os.avaliado_pelo_contratante;
        if (avaliacaoPendente) {
            return (
                <div className="conclusao-form">
                    <h3>Avaliação Pendente</h3>
                    <p>Este serviço foi concluído pelo trabalhador. Por favor, deixe sua avaliação para finalizar o processo.</p>
                    <FormularioAvaliacao 
                        onSubmit={handleAvaliarServicoConcluido} 
                        isSubmitting={isSubmitting}
                        isPendente={true}
                    />
                </div>
            );
        }

        if (showConcludeForm) {
            return (
                <div className="conclusao-form">
                    <h3>{isContratante ? 'Concluir e Avaliar Serviço' : 'Concluir Serviço'}</h3>
                    <textarea
                        placeholder={isContratante ? "Deixe um comentário sobre o serviço prestado..." : "Deixe seu relatório de conclusão ou orientações para o contratante."}
                        value={comentarioConclusao}
                        onChange={(e) => setComentarioConclusao(e.target.value)}
                        disabled={isSubmitting}
                    />
                    {isContratante && (
                        <FormularioAvaliacao 
                            onSubmit={handleConcluirServico} 
                            isSubmitting={isSubmitting}
                            comentarioConclusao={comentarioConclusao}
                        />
                    )}
                    {!isContratante && (
                        <div className="botoes-container">
                            <button onClick={() => handleConcluirServico()} className="btn btn-success" disabled={isSubmitting || !comentarioConclusao.trim()}>
                                {isSubmitting ? 'Confirmando...' : 'Confirmar Conclusão'}
                            </button>
                            <button onClick={() => setShowConcludeForm(false)} className="btn btn-secondary" disabled={isSubmitting}>Voltar</button>
                        </div>
                    )}
                </div>
            );
        }
        
        if (!isFinalizado) {
            return (
                <div className="botoes-container">
                    <button onClick={() => setShowConcludeForm(true)} className="btn btn-success" disabled={isSubmitting}>Concluir Serviço</button>
                </div>
            );
        }

        return null;
    };
    
    const renderConteudoPrincipal = () => {
        if (isLoading) return <div className="sala-trabalho-container-interno"><p>Carregando...</p></div>;
        if (error) return <div className="sala-trabalho-container-interno"><p className="error-message">{error}</p></div>;
        if (!os || !contratante || !trabalhador) return <div className="sala-trabalho-container-interno"><p>Não foi possível carregar os dados.</p></div>;

        const isFinalizado = os.status === 'concluida' || os.status === 'cancelada';

        return (
            <div className="sala-trabalho-container-interno">
                <div className="sala-trabalho-titulo-container">
                    <h2>{os.titulo_servico}</h2>
                    <span className={`os-status-badge status-${os.status}`}>{os.status.replace(/_/g, ' ')}</span>
                </div>
                <main className="sala-trabalho-main">
                    <section className="info-participantes">
                        <div className="perfil-card">
                            <h2>Contratante</h2>
                            <p>{contratante.apelido}</p>
                            <p><strong>Telefone:</strong> {contratante.telefone || 'Não informado'}</p>
                        </div>
                        <div className="perfil-card">
                            <h2>Trabalhador</h2>
                            <p>{trabalhador.apelido}</p>
                            <p><strong>Telefone:</strong> {trabalhador.telefone || 'Não informado'}</p>
                        </div>
                    </section>

                    <section className="info-servico">
                        <h2>Detalhes do Serviço</h2>
                        <p><strong>Descrição:</strong> {os.descricao_servico || 'Não informado'}</p>
                        <p><strong>Valor Acordado:</strong> R$ {os.valor_acordado}</p>
                        <p><strong>Habilidade Contratada:</strong> {os.habilidade_requerida || 'Não informada'}</p>
                        <p><strong>Endereço:</strong> {`${os.endereco.rua}, ${os.endereco.numero} - ${os.endereco.bairro}, ${os.endereco.cidade}`}</p>
                        <p><strong>Início Previsto:</strong> {new Date(os.data_inicio_prevista).toLocaleString()}</p>
                    </section>
                    
                    <section className="secao-chat">
                        <h2>Chat da Conversa</h2>
                        <div className="chat-box" ref={chatBoxRef}>
                            {mensagens.map(msg => (
                                <div key={msg.id} className={`chat-message ${msg.remetente_id === user.id ? 'minha-mensagem' : 'outra-mensagem'}`}>
                                    <p className="mensagem-conteudo">{msg.conteudo}</p>
                                    <span className="mensagem-timestamp">{new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                            ))}
                        </div>
                        {!isFinalizado && (
                            <form className="chat-input-area" onSubmit={handleEnviarMensagem}>
                                <input type="text" placeholder="Digite sua mensagem..." value={novaMensagem} onChange={(e) => setNovaMensagem(e.target.value)} />
                                <button type="submit" className="btn btn-primary" disabled={!novaMensagem.trim()}>Enviar</button>
                            </form>
                        )}
                    </section>
                    <section className="secao-acoes-finais">
                        <h2>Ações Finais</h2>
                        {renderAcoesFinais()}
                    </section>
                </main>
            </div>
        );
    };

    return (
        <div className="sala-trabalho-page-container">
            <HeaderEstiloTop showUserActions={false} />
            {renderConteudoPrincipal()}
        </div>
    );
};

export default SalaDeTrabalho;
