/**
 * @file DetalhesOS.js
 * @description Exibe os detalhes completos e o resultado final de uma Ordem de Serviço, com atalhos inteligentes para ações. (Versão Final Definitiva)
 * @author Jeferson Gnoatto & Manus AI
 * @date 2025-09-26
 * Louvado seja Cristo, Louvado seja Deus
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../services/supabaseClient';
import HeaderEstiloTop from './HeaderEstiloTop';
import './DetalhesOS.css';

// Componente auxiliar para exibir as estrelas (apenas visualização)
const EstrelasDisplay = ({ nota }) => {
  if (!nota || nota === 0) return <span className="estrelas-display-vazio">Não avaliado</span>;
  return (
    <div className="estrelas-display">
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < nota ? 'preenchida' : ''}>★</span>
      ))}
    </div>
  );
};

const DetalhesOS = () => {
  const { osId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [ordemDeServico, setOrdemDeServico] = useState(null);
  const [nomesEnvolvidos, setNomesEnvolvidos] = useState({ contratante: '', trabalhador: '' });
  const [avaliacao, setAvaliacao] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const carregarDetalhesOS = useCallback(async () => {
    if (!osId || !user) return;
    setIsLoading(true);
    try {
      const { data, error: fetchError } = await supabase.from('ordens_de_servico').select(`*`).eq('id', osId).single();
      if (fetchError) throw fetchError;

      if (data && (data.contratante_id === user.id || data.trabalhador_id === user.id || data.status === 'oferta_publica')) {
        setOrdemDeServico(data);
        
        const idsParaBuscar = [data.contratante_id];
        if (data.trabalhador_id) idsParaBuscar.push(data.trabalhador_id);
        
        const { data: perfisData, error: perfisError } = await supabase.from('perfis').select('id, apelido').in('id', idsParaBuscar);
        if (perfisError) throw perfisError;
        
        const nomes = {};
        perfisData.forEach(perfil => {
          if (perfil.id === data.contratante_id) nomes.contratante = perfil.apelido;
          if (perfil.id === data.trabalhador_id) nomes.trabalhador = perfil.apelido;
        });
        setNomesEnvolvidos(nomes);

        if (data.avaliado_pelo_contratante) {
          const { data: avaliacaoData, error: avaliacaoError } = await supabase
            .from('avaliacoes_quesitos')
            .select('quesito, nota')
            .eq('ordem_de_servico_id', osId);
          
          if (avaliacaoError) throw avaliacaoError;

          const avaliacaoObj = avaliacaoData.reduce((acc, item) => {
            acc[item.quesito] = item.nota;
            return acc;
          }, {});
          setAvaliacao(avaliacaoObj);
        }

      } else {
        throw new Error("Você não tem permissão para ver esta Ordem de Serviço.");
      }
    } catch (err) {
      console.error("Erro ao carregar detalhes da OS:", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [osId, user]);

  useEffect(() => {
    carregarDetalhesOS();
  }, [carregarDetalhesOS]);

  const isContratante = user && ordemDeServico && user.id === ordemDeServico.contratante_id;
  const isTrabalhador = user && ordemDeServico && user.id === ordemDeServico.trabalhador_id;
  const status = ordemDeServico?.status;

  const handleIrParaSalaDeTrabalho = () => navigate(`/trabalho/${osId}`);

  const renderConteudo = () => {
    if (isLoading) return <div className="detalhes-os-container"><p>Carregando detalhes...</p></div>;
    if (error) return <div className="detalhes-os-container"><p className="error-message">{error}</p></div>;
    if (!ordemDeServico) return <div className="detalhes-os-container"><p>Ordem de Serviço não encontrada.</p></div>;

    const detalhes = ordemDeServico.detalhes_adicionais || {};

    return (
      <main className="main-content">
        <div className="detalhes-os-container">
          <header className="detalhes-os-header">
            <h1>{ordemDeServico.titulo_servico || 'Detalhes da Ordem de Serviço'}</h1>
            <span className={`os-status-badge status-${status}`}>{status.replace(/_/g, ' ')}</span>
          </header>

          {(status === 'concluida' || status === 'cancelada') && (
            <div className="detalhes-os-section-final">
              <h2>Resumo Final</h2>
              {status === 'cancelada' && <p><strong>Motivo do Cancelamento:</strong> {ordemDeServico.motivo_cancelamento}</p>}
              {status === 'concluida' && (
                <>
                  <p><strong>Data de Conclusão:</strong> {new Date(ordemDeServico.data_conclusao_efetiva).toLocaleString()}</p>
                  {ordemDeServico.comentario_encerramento_contratante && <p><strong>Comentário do Contratante:</strong> {ordemDeServico.comentario_encerramento_contratante}</p>}
                  {ordemDeServico.comentario_encerramento_trabalhador && <p><strong>Relatório do Trabalhador:</strong> {ordemDeServico.comentario_encerramento_trabalhador}</p>}
                </>
              )}
            </div>
          )}

          {status === 'concluida' && avaliacao && (
            <div className="detalhes-os-section-avaliacao">
              <h2>Avaliação Realizada</h2>
              <div className="avaliacao-grid">
                <div className="quesito-display"><span>Pontualidade:</span> <EstrelasDisplay nota={avaliacao.pontualidade} /></div>
                <div className="quesito-display"><span>Comunicação:</span> <EstrelasDisplay nota={avaliacao.comunicacao} /></div>
                <div className="quesito-display"><span>Atenção ao Cliente:</span> <EstrelasDisplay nota={avaliacao.atencao_cliente} /></div>
                <div className="quesito-display"><span>Atenção aos Detalhes:</span> <EstrelasDisplay nota={avaliacao.atencao_detalhes} /></div>
                <div className="quesito-display"><span>Organização:</span> <EstrelasDisplay nota={avaliacao.organizacao} /></div>
                <div className="quesito-display"><span>Velocidade:</span> <EstrelasDisplay nota={avaliacao.velocidade_execucao} /></div>
                <div className="quesito-display"><span>Proatividade:</span> <EstrelasDisplay nota={avaliacao.proatividade} /></div>
              </div>
            </div>
          )}

          <div className="detalhes-os-grid">
            <div className="detalhes-os-section">
              <h2>Serviço Solicitado</h2>
              <p><strong>Habilidade Principal:</strong> {ordemDeServico.habilidade_requerida}</p>
              <p><strong>Descrição:</strong> {ordemDeServico.descricao_servico}</p>
              <p><strong>Valor Acordado:</strong> R$ {ordemDeServico.valor_acordado || 'A combinar'}</p>
              <p><strong>Início Previsto:</strong> {new Date(ordemDeServico.data_inicio_prevista).toLocaleString()}</p>
              <p><strong>Término Previsto:</strong> {new Date(ordemDeServico.data_conclusao).toLocaleString()}</p>
              {ordemDeServico.endereco && (
                <><p><strong>Endereço do Serviço:</strong></p><div className="endereco-detalhes">{`${ordemDeServico.endereco.rua} - ${ordemDeServico.endereco.numero}, ${ordemDeServico.endereco.bairro}, ${ordemDeServico.endereco.cidade} - ${ordemDeServico.endereco.estado}`}</div></>
              )}
            </div>
            <div className="detalhes-os-section">
              <h2>Envolvidos</h2>
              <p><strong>Contratante:</strong> {nomesEnvolvidos.contratante}</p>
              <p><strong>Trabalhador:</strong> {nomesEnvolvidos.trabalhador || 'Aguardando aceite'}</p>
            </div>
            <div className="detalhes-os-section full-width">
              <h2>Detalhes Adicionais e Observações</h2>
              <ul>
                {detalhes.necessario_transporte && <li>Necessário transporte até o local</li>}
                {detalhes.necessario_ferramentas && <li>Necessário que o trabalhador traga ferramentas</li>}
                {detalhes.necessario_refeicao && <li>Refeição inclusa no local</li>}
                {detalhes.necessario_ajudante && <li>Será necessário um ajudante</li>}
                {!detalhes.necessario_transporte && !detalhes.necessario_ferramentas && !detalhes.necessario_refeicao && !detalhes.necessario_ajudante && (<li>Nenhum detalhe adicional informado.</li>)}
              </ul>
              {ordemDeServico.observacoes ? (<p><strong>Observações:</strong> {ordemDeServico.observacoes}</p>) : (<p><strong>Observações:</strong> Nenhuma observação fornecida.</p>)}
            </div>
          </div>

          <div className="detalhes-os-actions">
            <h2>Ações</h2>
            <div className="botoes-container">
              {(status === 'aceita' || status === 'em_andamento') && (
                <button onClick={handleIrParaSalaDeTrabalho} className="btn btn-primary">Ir para Sala de Trabalho</button>
              )}
              {isContratante && status === 'concluida' && !ordemDeServico.avaliado_pelo_contratante && (
                <>
                  <p>Este serviço foi concluído pelo trabalhador. Sua avaliação está pendente.</p>
                  <button onClick={handleIrParaSalaDeTrabalho} className="btn btn-success">Avaliar Agora</button>
                </>
              )}
              {((status === 'concluida' && ordemDeServico.avaliado_pelo_contratante) || status === 'cancelada' || (isTrabalhador && status === 'concluida')) && (
                 <p>Não há mais ações disponíveis para este serviço.</p>
              )}
            </div>
          </div>
        </div>
      </main>
    );
  };

  return (
    <div className="page-container">
      <HeaderEstiloTop showUserActions={false} />
      {renderConteudo()}
    </div>
  );
};

export default DetalhesOS;
