// src/components/EstrelasDisplay.js

import React from 'react';
import './EstrelasDisplay.css'; // Vamos criar este arquivo de estilo também.

const EstrelasDisplay = ({ nota }) => {
  // Converte a nota para um número inteiro.
  const notaNumerica = parseInt(nota, 10);

  // Se a nota não for um número válido ou for zero, exibe um placeholder.
  if (isNaN(notaNumerica) || notaNumerica <= 0) {
    return <span className="estrelas-display-vazio">N/A</span>;
  }

  return (
    <div className="estrelas-display">
      {[...Array(5)].map((_, i) => (
        // Preenche a estrela se o índice for menor que a nota.
        <span key={i} className={i < notaNumerica ? 'preenchida' : ''}>★</span>
      ))}
    </div>
  );
};

export default EstrelasDisplay;
