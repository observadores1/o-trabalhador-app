/**
 * @file DetalhesOS.js
 * @description Exibe os detalhes completos e o resultado final de uma Ordem de Serviço. (Versão Final Restaurada)
 * @author Jeferson Gnoatto & Manus AI
 * @date 2025-09-26
 * Louvado seja Cristo, Louvado seja Deus
 */
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../services/supabaseClient';
import HeaderEstiloTop from './HeaderEstiloTop';
import './DetalhesOS.css';

const EstrelasDisplay = ({ nota }) => {
  if (!nota || nota === 0) return null;
  return (
    <div className="estrelas-display">
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < nota ? 'preenchida' : ''}>★</span>
      ))}
    </div>
  );
};

const DetalhesOS = () => {
  const { osId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [ordemDeServico, setOrdemDeServico] = useState(null);
  const [nomesEnvolvidos, setNomesEnvolvidos] = useState({ contratante: '', trabalhador: '' });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false); // Reintroduzido para os botões de ação

  const carregarDetalhesOS = useCallback(async () => {
    if (!osId || !user) return;
    setIsLoading(true);
    try {
      // A permissão de RLS já garante que o usuário possa ver a OS.
      const { data, error: fetchError } = await supabase.from('ordens_de_servico').select(`*`).eq('id', osId).single();
      if (fetchError) throw fetchError;

      setOrdemDeServico(data);
      
      const idsParaBuscar = [data.contratante_id, data.trabalhador_id].filter(Boolean);
      if (idsParaBuscar.length > 0) {
          const { data: perfisData, error: perfisError } = await supabase.from('perfis').select('id, apelido').in('id', idsParaBuscar);
          if (perfisError) throw perfisError;
          
          const nomes = {};
          perfisData.forEach(perfil => {
            if (perfil.id === data.contratante_id) nomes.contratante = perfil.apelido;
            if (perfil.id === data.trabalhador_id) nomes.trabalhador = perfil.apelido;
          });
          setNomesEnvolvidos(nomes);
      }
    } catch (err) {
      console.error("Erro ao carregar detalhes da OS:", err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [osId, user]);

  useEffect(() => { carregarDetalhesOS(); }, [carregarDetalhesOS]);

  // Lógica de Ação Reintroduzida
  const handleAceitarClick = async () => {
    if (!window.confirm('Tem certeza que deseja aceitar este serviço?')) return;
    setIsSubmitting(true);
    const { error: rpcError } = await supabase.rpc('aceitar_proposta', { 
      os_id_param: osId,
      trabalhador_id_param: user.id
    });
    if (rpcError) {
      alert(`Erro ao aceitar a proposta: ${rpcError.message}`);
      setIsSubmitting(false);
    } else {
      alert('Proposta aceita com sucesso! Você será redirecionado para a Sala de Trabalho.');
      navigate(`/trabalho/${osId}`); 
    }
  };

  const handleNegarClick = async () => {
    if (!window.confirm('Tem certeza que deseja negar esta proposta? Ela será removida de suas oportunidades.')) return;
    setIsSubmitting(true);
    const { error: rpcError } = await supabase.rpc('negar_proposta', { os_id_param: osId });
    if (rpcError) {
      alert(`Erro ao negar a proposta: ${rpcError.message}`);
    } else {
      alert('Proposta negada.');
      navigate('/oportunidades');
    }
    setIsSubmitting(false);
  };


  const renderAcoes = () => {
    if (!ordemDeServico || !user) return null;

    const isContratante = user.id === ordemDeServico.contratante_id;
    const isTrabalhadorAlvo = user.id === ordemDeServico.trabalhador_id;
    const isVisitante = !isContratante && !isTrabalhadorAlvo;
    const status = ordemDeServico.status;

    // Cenário 1: Contratante vendo sua própria OS em aberto
    if (isContratante && (status === 'oferta_publica' || status === 'pendente')) {
        return (
            <>
                <button onClick={() => navigate(`/os/${osId}/editar`)} className="btn btn-secondary" disabled={isSubmitting}>Editar</button>
                {/* Futuramente, adicionar botão de cancelar aqui */}
            </>
        );
    }

    // Cenário 2: Trabalhador vendo uma proposta direta para ele
    if (isTrabalhadorAlvo && status === 'pendente') {
        return (
            <>
                <button onClick={handleAceitarClick} className="btn btn-success" disabled={isSubmitting}>{isSubmitting ? 'Aceitando...' : 'Aceitar Proposta'}</button>
                <button onClick={handleNegarClick} className="btn btn-danger" disabled={isSubmitting}>{isSubmitting ? 'Negando...' : 'Negar Proposta'}</button>
            </>
        );
    }

    // Cenário 3: Trabalhador (visitante) vendo uma oferta pública
    if (isVisitante && status === 'oferta_publica') {
        return <button onClick={handleAceitarClick} className="btn btn-success" disabled={isSubmitting}>{isSubmitting ? 'Processando...' : 'Aceitar Trabalho'}</button>;
    }

    // Cenário 4: OS em andamento, para qualquer uma das partes
    if (status === 'aceita' || status === 'em_andamento') {
        return <button onClick={() => navigate(`/trabalho/${osId}`)} className="btn btn-primary">Ir para Sala de Trabalho</button>;
    }

    // Cenário 5: Contratante com avaliação pendente
    if (isContratante && status === 'concluida' && !ordemDeServico.avaliado_pelo_contratante) {
        return (
            <>
                <p>O trabalhador concluiu o serviço. Sua avaliação está pendente.</p>
                <button onClick={() => navigate(`/trabalho/${osId}`)} className="btn btn-success">Avaliar Agora</button>
            </>
        );
    }

    // Cenário Final: Nenhuma ação disponível
    return <p>Não há mais ações disponíveis para este serviço.</p>;
  };

  const renderConteudo = () => {
    if (isLoading) return <div className="detalhes-os-container"><p>Carregando detalhes...</p></div>;
    if (error) return <div className="detalhes-os-container"><p className="error-message">{error}</p></div>;
    if (!ordemDeServico) return <div className="detalhes-os-container"><p>Ordem de Serviço não encontrada.</p></div>;

    const detalhes = ordemDeServico.detalhes_adicionais || {};
    const status = ordemDeServico.status;

    return (
      <main className="main-content">
        <div className="detalhes-os-container">
          <header className="detalhes-os-header">
            <h1>{ordemDeServico.titulo_servico || 'Detalhes da Ordem de Serviço'}</h1>
            <span className={`os-status-badge status-${status}`}>{status.replace(/_/g, ' ')}</span>
          </header>

          {ordemDeServico.avaliado_pelo_contratante && (
            <div className="detalhes-os-section-avaliacao">
              <h2>Avaliação Realizada</h2>
              {ordemDeServico.avaliacao_texto && <p><strong>Comentário:</strong> {ordemDeServico.avaliacao_texto}</p>}
              {ordemDeServico.avaliacao_estrelas && (
                <div className="avaliacao-grid">
                  {Object.entries(ordemDeServico.avaliacao_estrelas).map(([quesito, nota]) => (
                      <div className="quesito-display" key={quesito}><span>{quesito.replace(/_/g, ' ')}:</span> <EstrelasDisplay nota={nota} /></div>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="detalhes-os-grid">
            <div className="detalhes-os-section">
              <h2>Serviço Solicitado</h2>
              <p><strong>Habilidade Principal:</strong> {ordemDeServico.habilidade_requerida}</p>
              <p><strong>Descrição:</strong> {ordemDeServico.descricao_servico}</p>
              <p><strong>Valor Acordado:</strong> R$ {ordemDeServico.valor_acordado || 'A combinar'}</p>
            </div>
            <div className="detalhes-os-section">
              <h2>Envolvidos</h2>
              <p><strong>Contratante:</strong> {nomesEnvolvidos.contratante}</p>
              <p><strong>Trabalhador:</strong> {nomesEnvolvidos.trabalhador || 'Aguardando aceite'}</p>
            </div>
            <div className="detalhes-os-section full-width">
              <h2>Detalhes Adicionais e Observações</h2>
              <ul>
                {detalhes.necessario_transporte && <li>Necessário transporte até o local</li>}
                {detalhes.necessario_ferramentas && <li>Necessário que o trabalhador traga ferramentas</li>}
                {detalhes.necessario_refeicao && <li>Refeição inclusa no local</li>}
                {detalhes.necessario_ajudante && <li>Será necessário um ajudante</li>}
                {(!detalhes.necessario_transporte && !detalhes.necessario_ferramentas && !detalhes.necessario_refeicao && !detalhes.necessario_ajudante) && (<li>Nenhum detalhe adicional informado.</li>)}
              </ul>
              {ordemDeServico.observacoes ? (<p><strong>Observações:</strong> {ordemDeServico.observacoes}</p>) : (<p><strong>Observações:</strong> Nenhuma observação fornecida.</p>)}
            </div>
          </div>

          <div className="detalhes-os-actions">
            <h2>Ações</h2>
            <div className="botoes-container">
              {renderAcoes()}
            </div>
          </div>
        </div>
      </main>
    );
  };

  return (
    <div className="page-container">
      <HeaderEstiloTop showUserActions={false} />
      {renderConteudo()}
    </div>
  );
};

export default DetalhesOS;
